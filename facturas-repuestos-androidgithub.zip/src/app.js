import {Filesystem,Directory,Encoding} from '@capacitor/filesystem';
import {Share} from '@capacitor/share';
import {App} from '@capacitor/app';

const ST={ok:'Instalado',bad:'Devuelto',wa:'Pendiente'};
let invs=[],cur=null,isNew=false,filter='all',q='',tool='ok',draw=false,mem=false;
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);

function dbOpen(){return new Promise((r,j)=>{const x=indexedDB.open('facturas_repuestos',1);x.onupgradeneeded=()=>x.result.createObjectStore('kv');x.onsuccess=()=>r(x.result);x.onerror=()=>j(x.error)})}
async function load(){try{const d=await dbOpen();invs=await new Promise(r=>{const x=d.transaction('kv').objectStore('kv').get('inv');x.onsuccess=()=>r(x.result||[]);x.onerror=()=>r([])})}catch(e){mem=true}}
async function save(){try{const d=await dbOpen();await new Promise(r=>{const t=d.transaction('kv','readwrite');t.objectStore('kv').put(invs,'inv');t.oncomplete=()=>r();t.onerror=()=>r()})}catch(e){mem=true}}

function compress(file){return new Promise(res=>{const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const m=1400,k=Math.min(1,m/Math.max(im.width,im.height));const c=document.createElement('canvas');c.width=im.width*k;c.height=im.height*k;c.getContext('2d').drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',.72))};im.src=fr.result};fr.readAsDataURL(file)})}

function counts(i){const c={ok:0,bad:0,wa:0};i.parts.forEach(p=>c[p.status]+=1);return c}
function home(){
  const all=invs.length,c={ok:0,bad:0};invs.forEach(i=>i.parts.forEach(p=>{if(p.status==='ok')c.ok++;if(p.status==='bad')c.bad++}));
  let l=invs.filter(i=>{const t=(i.num+i.sup+i.veh+i.parts.map(p=>p.name).join(' ')).toLowerCase();if(q&&!t.includes(q.toLowerCase()))return false;if(filter==='ret')return i.ret||i.parts.some(p=>p.status==='bad');if(filter==='pen')return i.parts.some(p=>p.status==='wa');return true}).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
  $('#app').innerHTML=`<h1>🧾 Facturas de repuestos</h1>
  <div class="stats"><div class="stat"><b>${all}</b><span>Facturas</span></div><div class="stat"><b style="color:var(--ok)">${c.ok}</b><span>Instalados</span></div><div class="stat"><b style="color:var(--bad)">${c.bad}</b><span>Devueltos</span></div></div>
  <div class="row" style="margin-bottom:10px"><input class="grow" id="q" placeholder="Buscar factura, proveedor, repuesto…" value="${esc(q)}"><button id="rep">📊 Informes</button><button class="pri" id="new">+ Nueva</button></div>
  <div class="row" style="margin-bottom:10px">${[['all','Todas'],['ret','Con devolución'],['pen','Con pendientes']].map(([k,t])=>`<button class="chip ${filter===k?'on':''}" data-f="${k}">${t}</button>`).join('')}</div>
  ${dl?`<div class="row" style="margin-bottom:10px"><button id="xl">⬇ Exportar a Excel</button><button id="bk">💾 Respaldo</button><label class="btn" style="margin:0">⬆ Restaurar<input type="file" id="rs" accept="*/*" hidden></label></div>`:''}
  ${l.length?l.map(i=>{const k=counts(i);return `<div class="card item" data-id="${i.id}">${i.img?`<img class="thumb" src="${i.img}">`:`<div class="thumb"></div>`}<div class="grow"><b>${esc(i.sup||'Sin proveedor')}</b> <span class="mut">#${esc(i.num||'—')}</span><div class="mut">${esc(i.date||'Sin fecha')}${i.veh?' · '+esc(i.veh):''}${i.total?' · $'+esc(i.total):''}</div><div>${k.ok?`<span class="badge b-ok">${k.ok} instalado${k.ok>1?'s':''}</span>`:''}${k.bad?`<span class="badge b-bad">${k.bad} devuelto${k.bad>1?'s':''}</span>`:''}${k.wa?`<span class="badge b-wa">${k.wa} pendiente${k.wa>1?'s':''}</span>`:''}${i.ret?`<span class="badge b-bad">Factura devuelta</span>`:''}</div></div></div>`}).join(''):`<div class="card mut" style="text-align:center">No hay facturas todavía. Toca “+ Nueva” para empezar.</div>`}
  ${mem?'<p class="mut">⚠️ Este navegador no permite guardar; los datos se perderán al cerrar.</p>':''}`;
  $('#q').oninput=e=>{q=e.target.value;const p=e.target.selectionStart;home();const n=$('#q');n.focus();n.setSelectionRange(p,p)};
  if(dl){$('#xl').onclick=()=>dlSave('facturas-repuestos.csv',csvAll());$('#bk').onclick=()=>dlSave('respaldo-facturas-'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify({v:1,invs}));
    $('#rs').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const d=JSON.parse(await f.text());if(!Array.isArray(d.invs))throw 0;d.invs.forEach(n=>{const i=invs.findIndex(x=>x.id===n.id);if(i<0)invs.push(n);else invs[i]=n});await save();alert('Respaldo restaurado: '+d.invs.length+' facturas.');home()}catch(x){alert('El archivo no es un respaldo válido.')}}}
  $('#rep').onclick=report;
  $('#new').onclick=()=>{cur={id:uid(),num:'',sup:'',date:new Date().toISOString().slice(0,10),veh:'',total:'',ret:false,retDate:'',notes:'',img:'',marks:[],parts:[]};isNew=true;draw=false;edit()};
  document.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{filter=b.dataset.f;home()});
  document.querySelectorAll('.item').forEach(b=>b.onclick=()=>{cur=JSON.parse(JSON.stringify(invs.find(i=>i.id===b.dataset.id)));isNew=false;draw=false;edit()});
}

function marksHTML(){return cur.marks.map((m,n)=>`<div class="mk ${m.s}" data-n="${n}" style="left:${m.x}%;top:${m.y}%;width:${m.w}%;height:${m.h}%"></div>`).join('')}
function partsHTML(){return cur.parts.map((p,n)=>`<div class="part"><input class="nm" data-p="${n}" data-k="name" placeholder="Repuesto" value="${esc(p.name)}"><input data-p="${n}" data-k="qty" type="number" min="1" title="Cantidad" value="${esc(p.qty)}"><input data-p="${n}" data-k="val" inputmode="decimal" placeholder="Valor total $" value="${esc(p.val||'')}"><select data-p="${n}" data-k="status">${Object.entries(ST).map(([k,t])=>`<option value="${k}" ${p.status===k?'selected':''}>${t}</option>`).join('')}</select><button class="dng" data-del="${n}" style="padding:0">✕</button></div>`).join('')||'<div class="mut">Aún no hay repuestos.</div>'}
function psum(){const c=cur,el=$('#psum');if(!el)return;const a=c.parts.reduce((x,p)=>x+num(p.val),0),b=c.parts.filter(p=>p.status==='bad').reduce((x,p)=>x+num(p.val),0);
  el.innerHTML=a?`Suma de repuestos: <b>${money(a)}</b>${b?` · Devuelto: <b style="color:var(--bad)">${money(b)}</b> · Neto: <b>${money(a-b)}</b>`:''}${num(c.total)!==a?` <button id="ut" style="padding:4px 10px;margin-left:6px">Usar suma como total</button>`:''}`:''}

function edit(){
  const c=cur;
  $('#app').innerHTML=`<div class="row" style="margin-bottom:10px"><button id="back">← Volver</button><div class="grow"></div><button class="pri" id="save">Guardar</button></div>
  <h1>${isNew?'Nueva factura':'Factura #'+esc(c.num)}</h1>
  <div class="card"><div class="row"><label class="btn" style="margin:0">📷 ${c.img?'Cambiar foto':'Tomar / subir foto'}<input type="file" id="file" accept="image/*" hidden></label>
  ${c.img?`<button id="dr" class="chip ${draw?'on':''}">✏️ Resaltar</button>`:''}${c.img&&aiOK?`<button id="ai">✨ Leer con IA</button>`:''}</div>
  ${c.img?`<div class="row" style="margin:10px 0 6px">${Object.entries(ST).map(([k,t])=>`<button class="chip ${tool===k?'on':''}" data-t="${k}"><span class="sw" style="background:var(--${k})"></span>${t}</button>`).join('')}</div>
  <div class="mut" style="margin-bottom:6px">${draw?'Arrastra sobre la foto para resaltar un repuesto.':'Toca “Resaltar” para marcar. Toca un resaltado para borrarlo.'}</div>
  <div class="photo" id="ph"><img src="${c.img}">${'<div id="mks">'+marksHTML()+'</div>'}${draw?'<div class="layer" id="ly"></div>':''}</div>`:''}</div>
  <div class="card"><div class="row"><div class="grow"><label>N.º de factura</label><input data-f="num" value="${esc(c.num)}"></div><div class="grow"><label>Fecha de compra</label><input type="date" data-f="date" value="${esc(c.date)}"></div></div>
  <label>Proveedor / almacén</label><input data-f="sup" value="${esc(c.sup)}">
  <div class="row"><div class="grow"><label>Vehículo / equipo</label><input data-f="veh" value="${esc(c.veh)}"></div><div class="grow"><label>Total</label><input data-f="total" inputmode="decimal" value="${esc(c.total)}"></div></div>
  <label style="display:flex;gap:8px;align-items:center;color:var(--tx);font-size:15px"><input type="checkbox" id="ret" style="width:auto" ${c.ret?'checked':''}> Se devolvió la factura completa</label>
  <div id="rd" ${c.ret?'':'hidden'}><label>Fecha de devolución</label><input type="date" data-f="retDate" value="${esc(c.retDate)}"></div>
  <label>Notas</label><textarea rows="2" data-f="notes">${esc(c.notes)}</textarea></div>
  <div class="card"><b>Repuestos</b><div id="parts" style="margin-top:8px">${partsHTML()}</div><div id="psum" class="mut" style="margin:6px 0 10px"></div><button id="add">+ Agregar repuesto</button></div>
  ${isNew?'':'<button class="dng" id="rm">Eliminar factura</button>'}`;
  $('#back').onclick=home;
  $('#save').onclick=async()=>{const i=invs.findIndex(x=>x.id===cur.id);if(i<0)invs.push(cur);else invs[i]=cur;await save();home()};
  document.querySelectorAll('[data-f]').forEach(e=>e.oninput=()=>{c[e.dataset.f]=e.value;if(e.dataset.f==='total')psum()});
  $('#ret').onchange=e=>{c.ret=e.target.checked;$('#rd').hidden=!c.ret};
  $('#file').onchange=async e=>{if(e.target.files[0]){c.img=await compress(e.target.files[0]);edit()}};
  $('#add').onclick=()=>{c.parts.push({name:'',qty:1,val:'',status:'ok'});$('#parts').innerHTML=partsHTML();psum()};
  $('#psum').onclick=e=>{if(e.target.id==='ut'){c.total=String(Math.round(c.parts.reduce((x,p)=>x+num(p.val),0)));document.querySelector('[data-f="total"]').value=c.total;psum()}};psum();
  $('#parts').oninput=e=>{const d=e.target.dataset;if(d.p!==undefined){c.parts[d.p][d.k]=e.target.value;psum()}};
  $('#parts').onclick=e=>{const n=e.target.dataset.del;if(n!==undefined){c.parts.splice(n,1);$('#parts').innerHTML=partsHTML();psum()}};
  if($('#rm'))$('#rm').onclick=async()=>{if(confirm('¿Eliminar esta factura?')){invs=invs.filter(x=>x.id!==c.id);await save();home()}};
  if(c.img){
    if($('#ai'))$('#ai').onclick=readAI;
    if($('#dr'))$('#dr').onclick=()=>{draw=!draw;edit()};
    document.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{tool=b.dataset.t;edit()});
    $('#mks').onclick=e=>{if(draw)return;const n=e.target.dataset.n;if(n!==undefined&&confirm('¿Borrar este resaltado?')){c.marks.splice(n,1);$('#mks').innerHTML=marksHTML()}};
    const ly=$('#ly');
    if(ly){let sx,sy,t;const pt=e=>{const r=ly.getBoundingClientRect();return[Math.min(100,Math.max(0,(e.clientX-r.left)/r.width*100)),Math.min(100,Math.max(0,(e.clientY-r.top)/r.height*100))]};
      ly.onpointerdown=e=>{ly.setPointerCapture(e.pointerId);[sx,sy]=pt(e);t=document.createElement('div');t.className='mk '+tool;ly.appendChild(t)};
      ly.onpointermove=e=>{if(!t)return;const[x,y]=pt(e);Object.assign(t.style,{left:Math.min(x,sx)+'%',top:Math.min(y,sy)+'%',width:Math.abs(x-sx)+'%',height:Math.abs(y-sy)+'%'})};
      ly.onpointerup=e=>{if(!t)return;const[x,y]=pt(e);const w=Math.abs(x-sx),h=Math.abs(y-sy);t.remove();t=null;if(w>1.5&&h>1.5){c.marks.push({x:Math.min(x,sx),y:Math.min(y,sy),w,h,s:tool});$('#mks').innerHTML=marksHTML()}}}
  }
}

const num=t=>{let s=String(t??'').replace(/[^\d.,]/g,'');if(!s)return 0;if(s.includes(',')&&s.includes('.'))s=s.replace(/\./g,'').replace(',','.');else if(s.includes(','))s=s.replace(',','.');else if(/^\d{1,3}(\.\d{3})+$/.test(s))s=s.replace(/\./g,'');return parseFloat(s)||0};
const invBase=i=>num(i.total)||i.parts.reduce((a,p)=>a+num(p.val),0);
const badVal=i=>i.parts.filter(p=>p.status==='bad').reduce((a,p)=>a+num(p.val),0);
const money=n=>'$'+Math.round(n).toLocaleString('es-CO');
const pd=s=>{const[a,b,c]=s.split('-').map(Number);return new Date(a,b-1,c)};
const iso=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const fmtD=d=>d.toLocaleDateString('es-CO',{day:'numeric',month:'short'});
const satKey=i=>{const d=pd(i.date);d.setDate(d.getDate()+6-d.getDay());return iso(d)};
function agg(kf){const m={};invs.filter(i=>i.date).forEach(i=>{const k=kf(i),sp=i.sup||'Sin proveedor',g=m[k]=m[k]||{k,net:0,ret:0,n:0,ok:0,bad:0,sup:{},list:[]},t=invBase(i);
  if(i.ret)g.ret+=t;else{const r=Math.min(t,badVal(i));g.ret+=r;g.net+=t-r;g.sup[sp]=(g.sup[sp]||0)+t-r}g.n++;g.ok+=i.parts.filter(p=>p.status==='ok').length;g.bad+=i.parts.filter(p=>p.status==='bad').length;g.list.push(i)});
  return Object.values(m).sort((a,b)=>b.k.localeCompare(a.k))}
let rtab='week';
function label(x,wk){if(wk){const sat=pd(x.k),sun=new Date(sat);sun.setDate(sat.getDate()-6);return 'Semana del dom '+fmtD(sun)+' al sáb '+fmtD(sat)}const t=pd(x.k+'-01').toLocaleDateString('es-CO',{month:'long',year:'numeric'});return t[0].toUpperCase()+t.slice(1)}
function report(){
  const wk=rtab==='week',g=agg(wk?satKey:i=>i.date.slice(0,7)),today=iso(new Date()),nod=invs.filter(i=>!i.date).length;
  const tot=g.reduce((a,x)=>a+x.net,0);
  $('#app').innerHTML=`<div class="row" style="margin-bottom:10px"><button id="back">← Volver</button><div class="grow"></div>${dl?'<button id="xr">⬇ Exportar</button>':''}</div><h1>📊 Informes de gasto</h1>
  <div class="row" style="margin-bottom:10px"><button class="chip ${wk?'on':''}" data-r="week">Semanal (cierre sábado)</button><button class="chip ${wk?'':'on'}" data-r="month">Mensual</button></div>
  <div class="mut" style="margin-bottom:10px">El gasto neto descuenta las facturas devueltas completas y el valor de los repuestos marcados como devueltos. Para que sea exacto, anota el valor de cada repuesto.${nod?' '+nod+' factura(s) sin fecha no se cuentan.':''}</div>
  ${g.length?g.map(x=>{const open=wk&&x.k>=today;return `<div class="card"><div class="row"><b class="grow">${label(x,wk)}</b>${open?'<span class="badge b-wa">En curso</span>':''}</div>
  <div style="font-size:26px;font-weight:700">${money(x.net)}</div>
  <div class="mut">${x.n} factura${x.n>1?'s':''} · ${x.ok} instalado${x.ok===1?'':'s'} · ${x.bad} devuelto${x.bad===1?'':'s'}${x.ret?' · valor devuelto: '+money(x.ret):''}</div>
  ${wk?x.list.sort((a,b)=>a.date.localeCompare(b.date)).map(i=>`<div class="mut" style="margin-top:4px">${i.date.slice(5)} · ${esc(i.sup||'—')} #${esc(i.num||'—')} · ${money(invBase(i))}${i.ret?' (devuelta)':badVal(i)?' (devuelto '+money(badVal(i))+')':''}</div>`).join('')
  :Object.entries(x.sup).sort((a,b)=>b[1]-a[1]).map(([n,v])=>`<div style="margin-top:8px"><div class="row mut"><span class="grow">${esc(n)}</span>${money(v)}</div><div style="height:6px;border-radius:4px;background:var(--bd)"><div style="height:6px;border-radius:4px;background:var(--ac);width:${x.net?v/x.net*100:0}%"></div></div></div>`).join('')}</div>`}).join('')+`<div class="mut" style="text-align:center">Total de todos los periodos: <b>${money(tot)}</b></div>`:'<div class="card mut">Aún no hay facturas con fecha.</div>'}`;
  $('#back').onclick=home;
  document.querySelectorAll('[data-r]').forEach(b=>b.onclick=()=>{rtab=b.dataset.r;report()});
  if(dl)$('#xr').onclick=()=>{const r=[['Periodo','Facturas','Gasto neto','Valor devuelto','Repuestos instalados','Repuestos devueltos']];
    g.forEach(x=>r.push([label(x,wk),x.n,Math.round(x.net),Math.round(x.ret),x.ok,x.bad]));
    dlSave(wk?'informe-semanal.csv':'informe-mensual.csv','\ufeff'+r.map(a=>a.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(';')).join('\r\n'))};
}
let dl=true,sm=null,aiOK=false;
async function dlSave(name,data){try{const r=await Filesystem.writeFile({path:name,data,directory:Directory.Cache,encoding:Encoding.UTF8});await Share.share({title:name,files:[r.uri],dialogTitle:'Guardar o enviar'})}catch(e){if(!/cancel/i.test((e&&e.message)||''))alert('No se pudo guardar el archivo.')}}
function csvAll(){const r=[['Factura','Proveedor','Fecha compra','Vehículo','Total','Factura devuelta','Fecha devolución','Repuesto','Cantidad','Valor repuesto','Estado','Notas']];
  invs.forEach(i=>(i.parts.length?i.parts:[{name:'',qty:'',status:''}]).forEach(p=>r.push([i.num,i.sup,i.date,i.veh,i.total,i.ret?'Sí':'No',i.retDate,p.name,p.qty,p.val||'',ST[p.status]||'',i.notes])));
  return '\ufeff'+r.map(x=>x.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n')}
function toBlob(u){const b=atob(u.split(',')[1]),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return new Blob([a],{type:'image/jpeg'})}
async function readAI(){
  const b=$('#ai');b.disabled=true;b.textContent='⏳ Leyendo factura…';
  try{
    const r=await sm.json('Esta es la foto de una factura de repuestos. Extrae los datos y responde SOLO un JSON con esta forma: {"numero":"","proveedor":"","fecha":"YYYY-MM-DD o vacío","total":"solo número","repuestos":[{"nombre":"","cantidad":1,"valor":0,"caja":[x,y,ancho,alto]}]}. "valor" es el valor total de esa línea (cantidad por precio), solo el número. "caja" es el rectángulo aproximado de la línea de ese repuesto en la foto, en porcentaje (0 a 100) del ancho y alto de la imagen. Si un dato no se ve, déjalo vacío.',{images:toBlob(cur.img)});
    if(!cur.num)cur.num=r.numero||'';if(!cur.sup)cur.sup=r.proveedor||'';if(r.fecha&&/^\d{4}-\d{2}-\d{2}$/.test(r.fecha))cur.date=r.fecha;if(!cur.total)cur.total=String(r.total||'');
    (r.repuestos||[]).forEach(p=>{cur.parts.push({name:p.nombre||'',qty:p.cantidad||1,val:p.valor?String(p.valor):'',status:'wa'});const k=p.caja;
      if(Array.isArray(k)&&k.length===4&&k.every(Number.isFinite)){const x=Math.max(0,Math.min(99,k[0])),y=Math.max(0,Math.min(99,k[1]));cur.marks.push({x,y,w:Math.min(100-x,k[2]),h:Math.min(100-y,k[3]),s:'wa'})}});
  }catch(e){alert(e&&e.code==='not_granted'?'Debes permitir el acceso para que Claude lea la factura.':'No pude leer la factura. Prueba con una foto más nítida.')}
  edit();
}
load().then(home);
App.addListener('backButton',()=>{if($('#new'))App.exitApp();else home()});
